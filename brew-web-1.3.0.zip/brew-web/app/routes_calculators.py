from flask import Blueprint, render_template
from flask_login import login_required

calculator_bp = Blueprint('calculator_bp', __name__, url_prefix='/calculator')

@calculator_bp.route('/')
@login_required
def calculator_index():
    return render_template("calculators/index.html")

@calculator_bp.route('/abv')
@login_required
def calculator_abv():
    return render_template("calculators/abv.html")

@calculator_bp.route('/dilution')
@login_required
def calculator_dilution():
    return render_template("calculators/dilution.html")

@calculator_bp.route('/volume-recovery')
@login_required
def calculator_volume_recovery():
    return render_template("calculators/volume_recovery.html")

@calculator_bp.route('/honey-needed')
@login_required
def calculator_honey_needed():
    return render_template("calculators/honey_needed.html")

@calculator_bp.route('/sweetness')
@login_required
def calculator_sweetness():
    return render_template("calculators/sweetness.html")

@calculator_bp.route('/carbonation')
@login_required
def calculator_carbonation():
    return render_template("calculators/carbonation.html")

@calculator_bp.route('/tosna')
@login_required
def calculator_tosna():
    return render_template("calculators/tosna.html")

@calculator_bp.route('/temp-correction')
@login_required
def calculator_temp_correction():
    return render_template("calculators/temp_correction.html")
