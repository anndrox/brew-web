from flask import Blueprint, render_template, request, redirect, url_for, flash
from .models import db, Recipe, Batch, Measurement, Ingredient, User
from datetime import datetime
from sqlalchemy.orm import joinedload
from app.utils import role_required
import re

routes = Blueprint('routes', __name__)

from flask_login import login_user, logout_user, current_user, login_required
# === INIT ===
@routes.route('/login', methods=['GET', 'POST'])
def login():
    if not User.query.first():
        return redirect(url_for('routes.setup'))
    if User.query.count() == 0:
        new_user.is_admin = True
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        user = User.query.filter_by(username=username).first()

        if user and user.check_password(password):
            login_user(user)
            flash('Logged in successfully.', 'success')
            return redirect(url_for('routes.index'))
        else:
            flash('Invalid username or password.', 'error')

    return render_template('login.html')

@routes.route('/logout')
@login_required
def logout():
    logout_user()
    flash('Logged out successfully.', 'success')
    return redirect(url_for('routes.login'))


@routes.route('/')
@login_required
def index():
    mead_recipes = Recipe.query.filter_by(alcohol_type='Mead').order_by(Recipe.name.asc()).all()
    wine_recipes = Recipe.query.filter_by(alcohol_type='Wine').order_by(Recipe.name.asc()).all()
    beer_recipes = Recipe.query.filter_by(alcohol_type='Beer').order_by(Recipe.name.asc()).all()
    other_recipes = Recipe.query.filter(Recipe.alcohol_type == None).order_by(Recipe.name.asc()).all()

    return render_template(
    'index.html',
    mead_recipes=mead_recipes,
    wine_recipes=wine_recipes,
    beer_recipes=beer_recipes
    )
 
# === BATCHES ===
@routes.route('/batches')
@login_required
def batches():
    mead_batches = Batch.query.filter_by(alcohol_type='Mead').order_by(Batch.start_date.asc()).all()
    wine_batches = Batch.query.filter_by(alcohol_type='Wine').order_by(Batch.start_date.asc()).all()
    beer_batches = Batch.query.filter_by(alcohol_type='Beer').order_by(Batch.start_date.asc()).all()
    other_batches = Batch.query.filter(
        (Batch.alcohol_type == None) | (Batch.alcohol_type.notin_(['Mead', 'Wine', 'Beer']))
    ).order_by(Batch.start_date.asc()).all()

    return render_template(
        'batches.html',
        mead_batches=mead_batches,
        wine_batches=wine_batches,
        beer_batches=beer_batches,
        other_batches=other_batches
    )

    return render_template('batches.html', batches=batches)

@routes.route('/batches/new', methods=['GET', 'POST'])
@login_required
@role_required('admin', 'editor')
def new_batch():
    recipes = Recipe.query.all()
    if not recipes:
        return redirect(url_for('routes.new_recipe'))
    if request.method == 'POST':
        try:
            ig = float(request.form['initial_gravity']) if request.form['initial_gravity'] else 0.0
            fg = float(request.form['final_gravity']) if request.form['final_gravity'] else 0.0
            abv = (ig - fg) * 131.25 if ig and fg else 0.0

            batch = Batch(
                recipe_id=int(request.form['recipe_id']) if request.form['recipe_id'] else None,
                name=request.form['name'],
                start_date=datetime.strptime(request.form['start_date'], '%Y-%m-%d') if request.form['start_date'] else None,
                end_date=datetime.strptime(request.form['end_date'], '%Y-%m-%d') if request.form['end_date'] else None,
                fermentation_temp=request.form['fermentation_temp'] or None,
                initial_gravity=ig,
                final_gravity=fg,
                abv=abv,
                yeast_type=request.form['yeast_type'] or None,
                backsweetened='backsweetened' in request.form,
                flavor_additions=request.form['flavor_additions'] or None,
                pectic_used='pectic_used' in request.form,
                notes=request.form['notes'] or None,
                alcohol_type=request.form.get('alcohol_type') or None,
                water_type=request.form.get('water_type') or None
                
            )

            db.session.add(batch)
            db.session.commit()
            flash("Batch created.", "success")
            return redirect(url_for('routes.batches'))
        except Exception:
            import traceback
            traceback.print_exc()
            raise

    return render_template('new_batch.html', recipes=recipes)

@routes.route('/batches/<int:batch_id>')
@login_required
def view_batch(batch_id):
    batch = Batch.query.get_or_404(batch_id)
    return render_template('batch_detail.html', batch=batch)

@routes.route('/batches/<int:batch_id>/edit', methods=['GET', 'POST'])
@login_required
@role_required('admin', 'editor')
def edit_batch(batch_id):
    batch = Batch.query.get_or_404(batch_id)
    if request.method == 'POST':
        ig = float(request.form['initial_gravity']) if request.form['initial_gravity'] else 0.0
        fg = float(request.form['final_gravity']) if request.form['final_gravity'] else 0.0
        abv = (ig - fg) * 131.25 if ig and fg else 0.0

        batch.name = request.form['name']
        batch.recipe_id = int(request.form['recipe_id']) if request.form['recipe_id'] else None
        batch.start_date = datetime.strptime(request.form['start_date'], '%Y-%m-%d') if request.form['start_date'] else None
        batch.end_date = datetime.strptime(request.form['end_date'], '%Y-%m-%d') if request.form['end_date'] else None
        batch.fermentation_temp = request.form['fermentation_temp'] or None
        batch.initial_gravity = ig
        batch.final_gravity = fg
        batch.abv = abv
        batch.yeast_type = request.form['yeast_type'] or None
        batch.backsweetened = 'backsweetened' in request.form
        batch.flavor_additions = request.form['flavor_additions'] or None
        batch.pectic_used = 'pectic_used' in request.form
        batch.notes = request.form['notes'] or None
        batch.alcohol_type = request.form.get('alcohol_type') or None
        batch.water_type = request.form.get('water_type') or None

        db.session.commit()
        flash("Batch updated successfully.", "success")
        return redirect(url_for('routes.view_batch', batch_id=batch.id))

    return render_template('edit_batch.html', batch=batch, recipes=Recipe.query.all())

@routes.route('/batches/<int:batch_id>/delete', methods=['POST'])
@login_required
@role_required('admin')
def delete_batch(batch_id):
    batch = Batch.query.get_or_404(batch_id)
    db.session.delete(batch)
    db.session.commit()
    flash(f'Batch \"{batch.name}\" was deleted.', 'success')
    return redirect(url_for('routes.batches'))

# === YEASTS ===
@routes.route('/yeasts')
def yeasts():
    return render_template('yeasts.html')

# === MEASUREMENTS ===
@routes.route('/measurements/new', methods=['GET', 'POST'])
@login_required
@role_required('admin', 'editor')
def new_measurement():
    batches = Batch.query.all()
    selected_id = request.args.get('batch_id', type=int)

    if request.method == 'POST':
        try:
            measurement = Measurement(
                batch_id=int(request.form['batch_id']),
                date=datetime.strptime(request.form['date'], '%Y-%m-%d'),
                gravity=float(request.form['gravity']) if request.form['gravity'] else None,
                ph=float(request.form['ph']) if request.form['ph'] else None,
                temperature=float(request.form['temperature']) if request.form['temperature'] else None,
                notes=request.form['notes']
            )
            db.session.add(measurement)
            db.session.commit()
            flash("Measurement added.", "success")
            return redirect(url_for('routes.view_batch', batch_id=measurement.batch_id))
        except Exception:
            import traceback
            traceback.print_exc()
            raise

    return render_template('new_measurement.html', batches=batches, selected_id=selected_id)

@routes.route('/measurements/<int:measurement_id>/delete', methods=['POST'])
@login_required
@role_required('admin')
def delete_measurement(measurement_id):
    measurement = Measurement.query.get_or_404(measurement_id)
    batch_id = measurement.batch_id
    db.session.delete(measurement)
    db.session.commit()
    flash("Measurement deleted successfully.", "success")
    return redirect(url_for('routes.view_batch', batch_id=batch_id))
# === RECIPES ===
@routes.route('/recipes')
@login_required
def recipes():
    return redirect(url_for('routes.index'))

@routes.route('/recipes/new', methods=['GET', 'POST'])
@login_required
@role_required('admin', 'editor')
def new_recipe():
    if request.method == 'POST':
        name = request.form['name']
        content = request.form['content']
        batch_size = int(request.form['batch_size'])

        recipe = Recipe(
        name=name,
        content=content,
        alcohol_type=request.form.get('alcohol_type') or None,
        water_type=request.form.get('water_type') or None
        )
        db.session.add(recipe)
        db.session.flush()

        i = 0
        while True:
            name_key = f"ingredient_name_{i}"
            if not request.form.get(name_key):
                break
            ingredient = Ingredient(
                recipe_id=recipe.id,
                name=request.form.get(name_key),
                amount_per_gallon=float(request.form.get(f"ingredient_amount_{i}") or 0),
                unit=request.form.get(f"ingredient_unit_{i}"),
                note=request.form.get(f"ingredient_note_{i}") or ""
            )
            db.session.add(ingredient)
            i += 1

        db.session.commit()
        flash("New recipe with ingredients added.", "success")
        return redirect(url_for('routes.index'))

    return render_template('new_recipe.html')

@routes.route('/recipes/<int:recipe_id>')
@login_required
def view_recipe(recipe_id):
    recipe = Recipe.query.get_or_404(recipe_id)
    target_batch = request.args.get('target_batch', type=int, default=1)
    return render_template('recipe_detail.html', recipe=recipe, target_batch=target_batch)

@routes.route('/recipes/<int:recipe_id>/edit', methods=['GET', 'POST'])
@login_required
@role_required('admin', 'editor')
def edit_recipe(recipe_id):
    recipe = Recipe.query.get_or_404(recipe_id)

    if request.method == 'POST':
        recipe.name = request.form['name']
        recipe.content = request.form['content']
        recipe.alcohol_type = request.form.get('alcohol_type') or None
        recipe.water_type = request.form.get('water_type') or None
        
        Ingredient.query.filter_by(recipe_id=recipe.id).delete()

        i = 0
        while True:
            name_key = f"ingredient_name_{i}"
            if not request.form.get(name_key):
                break
            ingredient = Ingredient(
                recipe_id=recipe.id,
                name=request.form.get(name_key),
                amount_per_gallon=float(request.form.get(f"ingredient_amount_{i}") or 0),
                unit=request.form.get(f"ingredient_unit_{i}"),
                note=request.form.get(f"ingredient_note_{i}") or ""
            )
            db.session.add(ingredient)
            i += 1

        db.session.commit()
        flash('Recipe updated successfully!', 'success')
        return redirect(url_for('routes.view_recipe', recipe_id=recipe.id))

    return render_template('edit_recipe.html', recipe=recipe)

@routes.route('/recipes/<int:recipe_id>/delete', methods=['POST'])
@login_required
@role_required('admin')
def delete_recipe(recipe_id):
    recipe = Recipe.query.get_or_404(recipe_id)
    db.session.delete(recipe)
    db.session.commit()
    flash(f'Recipe \"{recipe.name}\" was deleted.', 'success')
    return redirect(url_for('routes.index'))
# === STATS ===
@routes.route('/stats')
@login_required
def stats():
    batches = Batch.query.order_by(Batch.start_date).all()
    batch_names = [b.name for b in batches]
    abv_values = [round(b.abv or 0, 2) for b in batches]

    date_map = {}
    for b in batches:
        date_str = b.start_date.strftime('%Y-%m-%d') if b.start_date else 'Unknown'
        date_map[date_str] = date_map.get(date_str, 0) + 1

    dates = sorted(date_map.keys())
    counts = [date_map[d] for d in dates]

    return render_template('stats.html', batch_names=batch_names, abv_values=abv_values, dates=dates, counts=counts)

# === CALCULATORS ===

@routes.route('/calculators')
def calculator_index():
    return render_template('calculator_index.html')

@routes.route('/calculators/volume-recovery', methods=['GET', 'POST'])
def volume_recovery():
    result = None
    if request.method == 'POST':
        try:
            current_volume = float(request.form['current_volume'])
            target_volume = float(request.form['target_volume'])
            original_gravity = float(request.form['original_gravity'])

            added_volume = target_volume - current_volume
            if added_volume <= 0:
                result = {"error": "Target volume must be greater than current volume."}
            else:
                # Estimate honey and water needed to match OG
                # 1 lb of honey per gallon = approx 1.035 SG, so ~35 points
                points_per_lb_honey = 35
                total_points_needed = original_gravity * target_volume * 1000
                current_points = original_gravity * current_volume * 1000
                points_to_add = total_points_needed - current_points
                pounds_honey = points_to_add / points_per_lb_honey
                gallons_water = added_volume - (pounds_honey / 12)  # Rough adjustment

                result = {
                    "honey": round(pounds_honey, 2),
                    "water": round(gallons_water, 2)
                }
        except Exception:
            import traceback
            traceback.print_exc()
            raise

    return render_template('calculators/volume_recovery.html', result=result)


@routes.route('/calculators/abv', methods=['GET', 'POST'])
def calculator_abv():
    result = None
    if request.method == 'POST':
        try:
            og = float(request.form['og'])
            fg = float(request.form['fg'])
            abv = (og - fg) * 131.25
            result = round(abv, 2)
        except Exception:
            import traceback
            traceback.print_exc()
            raise

    return render_template('calculators/abv.html', result=result)

@routes.route('/calculators/sweetness', methods=['GET', 'POST'])
def calculator_sweetness():
    result = None
    if request.method == 'POST':
        og = float(request.form['og']) if request.form['og'] else 0
        desired_sg = float(request.form['desired_sg']) if request.form['desired_sg'] else 0
        honey_ppg = 35
        gallons = float(request.form['gallons']) if request.form['gallons'] else 1

        gravity_diff = desired_sg - og
        points_needed = gravity_diff * 1000
        pounds_needed = (points_needed * gallons) / honey_ppg

        result = round(pounds_needed, 2)

    return render_template('calculators/sweetness.html', result=result)

@routes.route('/calculators/dilution', methods=['GET', 'POST'])
def dilution_calculator():
    result = None
    if request.method == 'POST':
        try:
            original_volume = float(request.form['original_volume'])
            original_gravity = float(request.form['original_gravity'])
            target_gravity = float(request.form['target_gravity'])

            if target_gravity >= original_gravity:
                result = "Target gravity must be lower than original gravity."
            else:
                total_volume = (original_volume * original_gravity) / target_gravity
                water_to_add = total_volume - original_volume
                result = round(water_to_add, 2)
        except ValueError:
            result = "Invalid input."

    return render_template('calculators/dilution.html', result=result)

@routes.route('/calculators/honey-required', methods=['GET', 'POST'])
def calculator_honey_required():
    result = None
    if request.method == 'POST':
        try:
            volume = float(request.form['volume'])
            target_gravity = float(request.form['target_gravity'])
            base_gravity = 1.000
            gravity_points = (target_gravity - base_gravity) * 1000
            pounds_honey = (gravity_points * volume) / 35
            result = round(pounds_honey, 2)
        except:
            result = "Invalid input"

    return render_template('calculators/honey_required.html', result=result)

@routes.route('/calculators/carbonation', methods=['GET', 'POST'])
def carbonation_calculator():
    result = None
    if request.method == 'POST':
        try:
            volume = float(request.form['volume'])
            target_co2 = float(request.form['target_co2'])
            temp = float(request.form['current_temp'])

            existing_co2 = 3.0378 - (0.050062 * temp) + (0.00026555 * temp**2)
            sugar_oz = (target_co2 - existing_co2) * volume * 0.53
            result = round(sugar_oz, 2)
        except Exception:
            result = "Invalid input"
    return render_template('calculators/carbonation.html', result=result)

@routes.route('/calculators/tosna', methods=['GET', 'POST'])
def tosna_calculator():
    result = None
    if request.method == 'POST':
        try:
            volume = float(request.form['volume'])
            og = float(request.form['og'])

            base_gravity = 1.05
            if og < base_gravity:
                result = "OG too low for TOSNA."
            else:
                excess_gravity = og - base_gravity
                fermaid_o_per_gal = excess_gravity * 1000 * 0.0125
                total_fermaid_o = fermaid_o_per_gal * volume
                addition_per_day = total_fermaid_o / 4
                result = {
                    'total': round(total_fermaid_o, 2),
                    'per_day': round(addition_per_day, 2)
                }
        except Exception:
            result = "Invalid input"
    return render_template('calculators/tosna.html', result=result)

@routes.route('/calculators/temp_correction', methods=['GET', 'POST'])
def temp_correction():
    result = None
    if request.method == 'POST':
        try:
            reading = float(request.form['reading'])
            sample_temp = float(request.form['sample_temp'])
            calibration_temp = float(request.form['calibration_temp'])

            correction = (
                (1.00130346 - 0.000134722124 * sample_temp +
                 0.00000204052596 * sample_temp ** 2 -
                 0.00000000232820948 * sample_temp ** 3)
                /
                (1.00130346 - 0.000134722124 * calibration_temp +
                 0.00000204052596 * calibration_temp ** 2 -
                 0.00000000232820948 * calibration_temp ** 3)
            )
            corrected = reading * correction
            result = round(corrected, 4)
        except Exception:
            import traceback
            traceback.print_exc()
            raise
    return render_template('calculators/temp_correction.html', result=result)
    
# === CALCULATORS ===
@routes.route('/settings')
@login_required
def settings():
    return render_template('settings/settings.html')

# === SETTINGS ===
@routes.route('/settings/customize', methods=['GET', 'POST'])
@login_required
def settings_customize():
    if request.method == 'POST':
        current_user.theme = request.form.get('theme', 'dark')
        current_user.font_size = request.form.get('font_size', '16px')
        db.session.commit()
        flash('Appearance settings updated.', 'success')
    return render_template('settings/settings_customize.html')

@routes.route('/settings/password', methods=['GET', 'POST'])
@login_required
def settings_password():
    if request.method == 'POST':
        current = request.form['current_password']
        new = request.form['new_password']
        confirm = request.form['confirm_password']

        if not current_user.check_password(current):
            flash('Incorrect current password.', 'error')
        elif new != confirm:
            flash('New passwords do not match.', 'error')
        elif len(new) < 6:
            flash('Password must be at least 6 characters.', 'error')
        else:
            current_user.set_password(new)
            db.session.commit()
            flash('Password changed successfully.', 'success')
            return redirect(url_for('routes.settings_password'))

    return render_template('settings/settings_password.html')

from flask import abort
from flask_login import current_user

@routes.route('/settings/admin')
@login_required
def admin_settings():
    print("User:", current_user.username) #debug
    print("Role:", current_user.role) #debug
    print("Is admin:", current_user.is_admin) #debug
    if not current_user.is_admin:
        abort(403)
    
    users = User.query.order_by(User.username).all()
    return render_template('settings/admin.html', users=users)
    
@routes.route('/settings/admin/create_user', methods=['POST'])
@login_required
@role_required('admin')
def create_user():
    if not current_user.is_admin:
        abort(403)

    username = request.form['username']
    password = request.form['password']
    role = request.form.get('role', 'user')
    is_admin = role == 'admin'

    if User.query.filter_by(username=username).first():
        flash("Username already exists.", "error")
        return redirect(url_for('routes.admin_settings'))

    user = User(username=username, role=role, is_admin=is_admin)
    user.set_password(password)
    db.session.add(user)
    db.session.commit()

    flash("User created successfully.", "success")
    return redirect(url_for('routes.admin_settings'))

@routes.route('/settings/admin/delete_user/<int:user_id>', methods=['POST'])
@login_required
@role_required('admin')
def delete_user(user_id):
    if not current_user.is_admin:
        abort(403)

    user = User.query.get_or_404(user_id)
    if user.id == current_user.id:
        flash("You cannot delete your own account.", "error")
    else:
        db.session.delete(user)
        db.session.commit()
        flash(f"User '{user.username}' deleted.", "success")

    return redirect(url_for('routes.admin_settings'))

@routes.route('/settings/admin/reset_password/<int:user_id>', methods=['GET', 'POST'])
@login_required
@role_required('admin')
def reset_user_password(user_id):
    if not current_user.is_admin:
        abort(403)

    user = User.query.get_or_404(user_id)

    if request.method == 'POST':
        new_password = request.form['new_password']
        user.set_password(new_password)
        db.session.commit()
        flash("Password updated.", "success")
        return redirect(url_for('routes.admin_settings'))

    return render_template('settings/reset_password_admin.html', user=user)
