from flask import Flask, redirect, url_for, request
from flask_sqlalchemy import SQLAlchemy
from flask_migrate import Migrate
from flask_login import LoginManager
from markupsafe import Markup, escape

db = SQLAlchemy()
migrate = Migrate()
login_manager = LoginManager()

def create_app():
    app = Flask(__name__)
    app.config.from_object('config.Config')  # <-- USER MUST DEFINE config.Config properly

    db.init_app(app)
    migrate.init_app(app, db)
    login_manager.init_app(app)

    login_manager.login_view = 'auth_bp.login'
    from flask_login import current_user

    @app.context_processor
    def inject_theme():
        if current_user.is_authenticated:
            return {"theme": current_user.theme}
        return {"theme": "dark"}  # default fallback
    # ✅ This must be inside create_app and after login_manager.init_app(app)
    from .models import User

    @login_manager.user_loader
    def load_user(user_id):
        return User.query.get(int(user_id))

    # Redirect to /setup if no users exist
    @app.before_request
    def require_setup():
        if not User.query.first() and \
           request.endpoint not in ('auth_bp.setup', 'static'):
            return redirect(url_for('auth_bp.setup'))

    # Jinja2 filter
    @app.template_filter('nl2br')
    def nl2br_filter(s):
        return Markup('<br>'.join(escape(s).splitlines()))

    from . import routes
    app.register_blueprint(routes.routes)

    from .auth import auth_bp
    app.register_blueprint(auth_bp)

    return app
